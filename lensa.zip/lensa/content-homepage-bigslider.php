<div class="main-container container">
  <div class="row">
    <div class="slide-info-wrapper col10">
      <ul class="slide-nav">
        <li><a class="slide-prev" href="#"><i class="icon-chevron-left"></i></a></li>
        <li><a class="slide-next" href="#"><i class="icon-chevron-right"></i></a></li>
      </ul>
      <div class="slide-info">
        <h2 class="slide-title"><a href="#"></a></h2>
        <div class="slide-caption"></div>
      </div>
    </div><!-- .slide-info-wraper -->
  </div>
</div>