<?php

require_once( get_template_directory() . '/includes/flickr/wordpress-flickr.php' );