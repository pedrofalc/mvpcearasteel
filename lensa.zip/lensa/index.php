<?php get_header(); ?>

  <?php get_template_part('content','homepage-bigslider');?>

<?php get_footer(); ?>