lensa
=====

Lensa is a full-screen WordPress gallery theme designed for those of you who are addicted to high-resolution photography

[click here for more info](http://colorlabsproject.com/themes/lensa/)
