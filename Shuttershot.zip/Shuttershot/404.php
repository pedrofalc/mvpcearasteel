<?php get_header(); ?>
<div id="casing">
<div id="ncontent">
	<div class="npost">
		<div class="ntitle title">
			<h2>404-Not Found</h2>
		</div>
		<div class="nentry">
			<p>The page you are looking is not here.. please try a different search.</p>
		
		</div>
	</div>

</div>
</div>
<?php get_footer(); ?>